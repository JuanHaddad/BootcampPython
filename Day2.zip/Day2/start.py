# data types

#string

print(3 * (3 + 3) / 3 - 3)