# 🚨 Don't change the code below 👇
age = input("What is your current age? ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
years_left = 90 - int(age) 

print(f"You have {years_left*365} days, {years_left*52} weeks, and {years_left*12} months left.")
