import random

print(random.random()+random.randint(0,4))