print("Welcome to the rollercoaster!")
height = int(input("Whats your height in cm? "))

if height >=  120:
    print("You can ride the rollercoaster!!!!")
    age = int(input("Whats your age? "))
    if age < 12:
        bill = 5
        print("Please pay $5")
    elif age <= 18:
        bill = 7
        print("Please pay $7")
    elif age >= 45 and age <= 55:
        print("YOU HAVE A FREE RIDE !!!!!")
    else:
        bill = 12
        print("Please pay $12.")
    wants_photo = input("Do you want a photo taken? Y/N ")
    if wants_photo == "Y":
        bill += 3

    print(f"Your final bill is ${bill}")

else:
    print("Sorry, you have to grow taller before you can ride..")