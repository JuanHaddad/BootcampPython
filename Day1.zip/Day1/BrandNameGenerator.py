print("Welcome to the Band Name Generator.")
city = input("What's the name of the city you grew up?\n")
pet = input("What's your pet's name?\n")
print("Your band name could be " + city + " " + pet)